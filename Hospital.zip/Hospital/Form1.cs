﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Hospital.Form1;

namespace Hospital
{
    public partial class Form1 : Form
    {
        private List<Patient> patients;
        public Form1()
        {
            InitializeComponent();
            patients = new List<Patient>();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Simulate loading patients (This data can come from a database or API)
            LoadPatientsData();

            // Display patients in DataGridView
            dataGridView1.DataSource = patients.Select(p => new { p.PatientID, p.Name, p.Device }).ToList();

            // Populate ComboBox with patient names
            comboBoxPatients.Items.Clear();
            foreach (var patient in patients)
            {
                comboBoxPatients.Items.Add(patient.Name);
            }

            // If there are patients, select the first one by default
            if (comboBoxPatients.Items.Count > 0)
            {
                comboBoxPatients.SelectedIndex = 0;
            }
        }
        private void comboBoxPatients_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Get selected patient
            var selectedPatientName = comboBoxPatients.SelectedItem.ToString();
            var selectedPatient = patients.FirstOrDefault(p => p.Name == selectedPatientName);

            if (selectedPatient != null)
            {
                // Display health data and alert info
                labelHealthInfo.Text = $"Health Data: HeartRate={selectedPatient.HeartRate}, BP={selectedPatient.BloodPressure}, Temp={selectedPatient.Temperature}°F";
                labelAlert.Text = $"Health Alert: {selectedPatient.AlertMessage}";
            }
        }

        private void LoadPatientsData()
        {
            // Adding some dummy patient data to the list
            patients.Clear(); // Clear any existing data

            patients.Add(new Patient
            {
                PatientID = "P12345",
                Name = "John Doe",
                Device = "Smartwatch",
                HeartRate = 72,
                BloodPressure = "120/80",
                Temperature = 98.6,
                AlertMessage = "None"
            });

            patients.Add(new Patient
            {
                PatientID = "P12346",
                Name = "Jane Smith",
                Device = "ECG Monitor",
                HeartRate = 95,
                BloodPressure = "130/90",
                Temperature = 99.0,
                AlertMessage = "High Blood Pressure"
            });

            patients.Add(new Patient
            {
                PatientID = "P12347",
                Name = "Emily Johnson",
                Device = "Fitness Tracker",
                HeartRate = 68,
                BloodPressure = "118/76",
                Temperature = 98.1,
                AlertMessage = "None"
            });
        }

        // Class to represent a patient
        public class Patient
        {
            public string PatientID { get; set; }
            public string Name { get; set; }
            public string Device { get; set; }
            public int HeartRate { get; set; }
            public string BloodPressure { get; set; }
            public double Temperature { get; set; }
            public string AlertMessage { get; set; }
        }
    }
}
